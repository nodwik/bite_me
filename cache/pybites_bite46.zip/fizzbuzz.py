from typing import Union


def fizzbuzz(num: int) -> Union[str, int]:
    pass